# Rais thu chi — v0.0.1

Ứng dụng Android quản lý tài chính cá nhân, Java + AndroidX + SQLite, hoạt động ngoại tuyến.

## Thiết kế và tính năng
- Giao diện tông xanh ngọc, thẻ số dư, điều hướng dưới màn hình và icon app Rais riêng.
- Ghi khoản thu/chi theo danh mục, ghi chú, ngày và tài khoản.
- Danh sách giao dịch và tổng quan tài chính.
- Nhiều tài khoản: tiền mặt, ngân hàng Việt Nam phổ biến và ví điện tử (MoMo, ZaloPay, ShopeePay, VNPay, Viettel Money, PayPal...).
- Sổ nợ: khoản cần trả / cần thu, ghi chú và hạn thanh toán.
- Báo cáo tổng thu, tổng chi, chênh lệch và biểu đồ.
- Xuất dữ liệu JSON để sao lưu.

## Build
Dùng GitHub Actions workflow `build-android-apk.yml`. Để trống `zip_name` để chọn ZIP được cập nhật gần nhất trong thư mục gốc, hoặc nhập tên ZIP cụ thể.

## Cập nhật đè và dữ liệu
- applicationId: `vn.rais.thuchi` (không đổi).
- versionName: `0.0.1`, versionCode: `1`.
- Để cài đè mà giữ dữ liệu, các bản phát hành phải dùng cùng keystore và tăng versionCode. Không gỡ ứng dụng cũ.
- Nếu không cấu hình khóa ký release, workflow tạo APK debug chỉ để thử nghiệm.
- Danh sách ngân hàng/ví là nhãn để phân loại tài khoản; ứng dụng KHÔNG kết nối tài khoản ngân hàng, không lưu mật khẩu/OTP và không tự động đồng bộ số dư.
