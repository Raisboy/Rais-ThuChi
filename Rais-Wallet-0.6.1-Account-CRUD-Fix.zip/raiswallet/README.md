# Rais Wallet 0.6.0

Ứng dụng Android quản lý thu chi, dữ liệu lưu cục bộ. Phiên bản này bổ sung trang chuyển đổi ngoại tệ trực tuyến với tỷ giá tham khảo từ ExchangeRate-API Open Access (`open.er-api.com`), hỗ trợ tiền tệ VND và các mã tiền được nguồn tỷ giá trả về. Tỷ giá được lưu cache để có thể xem lại khi mất mạng. Tỷ giá cập nhật hằng ngày, không phải giá mua/bán tại ngân hàng hoặc báo giá giao dịch. Cần ghi nhận nguồn dữ liệu trong ứng dụng theo điều khoản nhà cung cấp.

- Application ID: `vn.rais.thuchi` (giữ nguyên để hỗ trợ nâng cấp)
- Version: `0.6.0` (versionCode 9)
- Java + AndroidX + Material Components
- Min SDK 21, target SDK 35
- GitHub Actions: build signed APK/AAB bằng 4 secrets RAIS hiện có.

## Tỷ giá
Endpoint công khai: `https://open.er-api.com/v6/latest/USD`. Dữ liệu cập nhật xấp xỉ mỗi 24 giờ; kết quả chỉ mang tính tham khảo.

## 0.6.1 – quản lý tài khoản linh hoạt hơn
- Chạm vào tài khoản hoặc nút ⋮ để chỉnh sửa tên, loại tài khoản, biểu tượng hoặc xoá.
- Có xác nhận trước khi xoá. Lưu ý: giao dịch gắn với tài khoản bị xoá cũng sẽ bị xoá để tránh dữ liệu mồ côi.
- Danh sách ngân hàng/ví hiển thị huy hiệu chữ viết tắt và màu nhận diện khác nhau; đây là huy hiệu nhận diện trong ứng dụng, **chưa phải bộ logo ảnh chính thức của từng thương hiệu**. Có thể gắn ảnh logo riêng cho tài khoản qua trình chọn ảnh.
- Giữ nguyên applicationId `vn.rais.thuchi`; versionCode 10 để cài cập nhật lên bản cũ nếu ký bằng đúng keystore hiện tại.
