# Rais Wallet 0.6.0

Ứng dụng Android quản lý thu chi, dữ liệu lưu cục bộ. Phiên bản này bổ sung trang chuyển đổi ngoại tệ trực tuyến với tỷ giá tham khảo từ ExchangeRate-API Open Access (`open.er-api.com`), hỗ trợ tiền tệ VND và các mã tiền được nguồn tỷ giá trả về. Tỷ giá được lưu cache để có thể xem lại khi mất mạng. Tỷ giá cập nhật hằng ngày, không phải giá mua/bán tại ngân hàng hoặc báo giá giao dịch. Cần ghi nhận nguồn dữ liệu trong ứng dụng theo điều khoản nhà cung cấp.

- Application ID: `vn.rais.thuchi` (giữ nguyên để hỗ trợ nâng cấp)
- Version: `0.6.0` (versionCode 9)
- Java + AndroidX + Material Components
- Min SDK 21, target SDK 35
- GitHub Actions: build signed APK/AAB bằng 4 secrets RAIS hiện có.

## Tỷ giá
Endpoint công khai: `https://open.er-api.com/v6/latest/USD`. Dữ liệu cập nhật xấp xỉ mỗi 24 giờ; kết quả chỉ mang tính tham khảo.
