package vn.rais.thuchi;
import android.app.*;import android.appwidget.*;import android.content.*;import android.widget.*;import java.text.*;import java.util.*;
public class BalanceWidgetProvider extends AppWidgetProvider{
 public void onUpdate(Context c,AppWidgetManager m,int[] ids){WalletDb db=new WalletDb(c);NumberFormat f=NumberFormat.getInstance(new Locale("vi","VN"));
  for(int id:ids){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_balance);v.setTextViewText(R.id.widget_balance,f.format(db.balance())+" ₫");v.setTextViewText(R.id.widget_summary,"Thu "+f.format(db.total("IN"))+" • Chi "+f.format(db.total("OUT")));
   Intent i=new Intent(c,MainActivity.class);PendingIntent p=PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);v.setOnClickPendingIntent(R.id.widget_balance,p);v.setOnClickPendingIntent(R.id.widget_summary,p);m.updateAppWidget(id,v);}
  db.close();
 }
 public static void refresh(Context c){Intent i=new Intent(c,BalanceWidgetProvider.class);i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS,AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,BalanceWidgetProvider.class)));c.sendBroadcast(i);}
}
