# Rais Wallet 0.5.0 — UI & Export Fix

- Package: `vn.rais.thuchi` (giữ nguyên để cập nhật đúng ứng dụng hiện có)
- Android Java / AndroidX / Material Components; min SDK 21; compile SDK 35.
- Dữ liệu giao dịch và tài khoản được lưu cục bộ bằng SQLite.

## Sửa trong bản này
- Bù system-bar insets để thanh trạng thái và thanh điều hướng không đè nội dung.
- Sửa bố cục dòng tài khoản: vùng tên dùng weight, tránh tên bị co còn vài ký tự.
- Chỉnh nhãn thanh điều hướng và bộ lọc báo cáo để hạn chế tràn chữ trên màn hình hẹp.
- Bộ lọc báo cáo Ngày/Tháng/Năm/Tất cả thực sự lọc tổng thu, tổng chi và dòng tiền ròng.
- Xuất giao dịch ra CSV UTF-8 BOM qua trình chọn tệp Android; có thể mở bằng Microsoft Excel / Google Sheets.
- Thêm luồng chọn ảnh PNG/JPG/WebP làm icon tài khoản và giữ quyền đọc URI.
- Icon ngân hàng/ví trong danh sách tài khoản dùng chữ viết tắt, màu phân biệt thay vì emoji ngẫu nhiên.
- Tăng versionCode lên 7, versionName lên 0.5.0; giữ nguyên applicationId và cơ sở dữ liệu hiện có.

## Lưu ý kiểm thử
Mã nguồn đã được kiểm tra cấu trúc ZIP và kiểm tra cân bằng dấu ngoặc cơ bản. Môi trường tạo bản vá không có Android SDK/Gradle để chạy build Android thực tế, vì vậy cần chạy GitHub Actions để xác nhận compile APK/AAB. Không coi đây là bản build đã kiểm chứng cho đến khi workflow thành công và cài thử trên thiết bị.

## Xuất Excel
Mục **Khác → Xuất Excel / CSV** hoặc **Báo cáo → Xuất Excel / CSV**. Android sẽ hỏi nơi lưu file `.csv`; Excel mở trực tiếp được. Bản này xuất CSV tương thích Excel, không phải tệp `.xlsx` gốc.

## Icon tài khoản tùy chỉnh
Vào **Ví tiền → Thêm ví → Chọn ảnh biểu tượng**, chọn ảnh trong trình chọn tệp, sau đó hoàn tất tên tài khoản và nhấn **Thêm**. App không kết nối tới ngân hàng.
