# Rais Thu Chi 0.3.0 — Green Offline Finance

Ứng dụng Android Java quản lý tài chính cá nhân, ưu tiên offline. Dữ liệu giao dịch/tài khoản/sổ nợ được lưu trong SQLite trên thiết bị.

## Thiết kế và chức năng
- Theme xanh lá, giao diện không có phần chào hỏi.
- Tổng quan số dư; thu/chi tháng hiện tại; giao dịch gần đây.
- Thêm khoản thu/chi, chọn danh mục và nguồn tiền.
- Nguồn tiền: tiền mặt, ngân hàng, ví điện tử; icon mặc định theo tên hoặc ảnh PNG/JPG/WebP do người dùng chọn.
- Sổ nợ, hạn đến hạn và ghi chú.
- Ẩn/hiện số tiền trong ứng dụng/widget.
- Chạm giữ giao dịch để bật/tắt việc tính khoản đó vào số dư và báo cáo hoặc xóa giao dịch; lịch sử vẫn được giữ nếu chỉ tắt tính.
- Bật/tắt danh mục.
- Widget màn hình chính Android hiển thị tổng quan tài chính.
- Sao lưu JSON qua Android Storage Access Framework.
- Báo cáo mặc định tháng hiện tại; tùy chọn xem hôm nay, tháng, năm, khoảng tùy chọn, hoặc toàn bộ lịch sử.
- Chọn kiểu biểu đồ độc lập trên tổng quan và báo cáo: cột, đường, vùng, tròn, vòng tròn, cột chồng.
- Quản lý ngân sách theo danh mục cho tháng hiện tại; xem tỷ lệ sử dụng, sửa hoặc xóa hạn mức.
- Phân tích chi tiêu theo danh mục.

## Lưu ý về tính toán
- Chỉ giao dịch bật `include_in_totals` mới tính vào số dư/báo cáo.
- Các giao dịch được ghi theo ngày ISO `yyyy-MM-dd`; báo cáo ngày/tháng/năm dựa trên ngày giao dịch.
- Dữ liệu chỉ ở máy, không tự đồng bộ giữa thiết bị và không kết nối API ngân hàng.
- Xuất và khôi phục bản sao JSON; khi khôi phục, dữ liệu hiện tại sẽ bị thay thế sau khi xác nhận. Sao lưu trước khi khôi phục.
- Biểu đồ nến tài chính không được bật mặc định vì ứng dụng chưa lưu OHLC (giá mở/cao/thấp/đóng) hay thời điểm từng giao dịch; các loại biểu đồ cột/đường/vùng/tròn phù hợp hơn với dữ liệu thu chi hiện có.

## Build bằng GitHub Actions
1. Upload ZIP này vào thư mục gốc repository GitHub.
2. Đặt workflow ở `.github/workflows/build-rais-release.yml` (file được cung cấp riêng).
3. Tạo các repository secrets: `RAIS_KEYSTORE_BASE64`, `RAIS_KEYSTORE_PASSWORD`, `RAIS_KEY_ALIAS`, `RAIS_KEY_PASSWORD`.
4. Chạy workflow. Để trống tên ZIP để chọn dự án ZIP mới nhất.
5. Tải APK và AAB từ Artifacts khi workflow thành công.

## Cập nhật an toàn
- Giữ nguyên `applicationId` là `vn.rais.thuchi`.
- Giữ nguyên keystore/alias/mật khẩu phát hành.
- Tăng `versionCode` mỗi lần phát hành mới.
- Không gỡ ứng dụng hoặc xóa dữ liệu khi cập nhật nếu muốn giữ SQLite.

## Trạng thái kiểm thử
Mã nguồn/ZIP được kiểm tra cấu trúc và XML tĩnh. APK/AAB chưa được build trong môi trường tạo ZIP này; cần chạy GitHub Actions để xác nhận biên dịch và ký phát hành thực tế.


## 0.3.1 — sửa tương phản giao diện
- Sửa lỗi thẻ tổng số dư và thẻ thống kê bị hàm tạo card ghi đè nền gradient thành trắng.
- Giữ nền tùy chỉnh cho các thẻ tổng quan và báo cáo.
- Tăng tương phản chữ trong bộ chọn biểu đồ/khoảng thời gian.
- Cập nhật cấu hình thanh trạng thái Android.
- Tăng versionCode lên 5, versionName 0.3.1; giữ applicationId `vn.rais.thuchi` để hỗ trợ cập nhật cùng khóa ký.
