# Rais Wallet 0.6.2

Ứng dụng Android quản lý thu chi, dữ liệu lưu cục bộ. Phiên bản này bổ sung trang chuyển đổi ngoại tệ trực tuyến với tỷ giá tham khảo từ ExchangeRate-API Open Access (`open.er-api.com`), hỗ trợ tiền tệ VND và các mã tiền được nguồn tỷ giá trả về. Tỷ giá được lưu cache để có thể xem lại khi mất mạng. Tỷ giá cập nhật hằng ngày, không phải giá mua/bán tại ngân hàng hoặc báo giá giao dịch. Cần ghi nhận nguồn dữ liệu trong ứng dụng theo điều khoản nhà cung cấp.

- Application ID: `vn.rais.thuchi` (giữ nguyên để hỗ trợ nâng cấp)
- Version: `0.6.0` (versionCode 9)
- Java + AndroidX + Material Components
- Min SDK 21, target SDK 35
- GitHub Actions: build signed APK/AAB bằng 4 secrets RAIS hiện có.

## Tỷ giá
Endpoint công khai: `https://open.er-api.com/v6/latest/USD`. Dữ liệu cập nhật xấp xỉ mỗi 24 giờ; kết quả chỉ mang tính tham khảo.

## 0.6.2 – hoàn thiện luồng tài khoản và logo cá nhân
- Chạm vào tài khoản hoặc nút ⋮ để chỉnh sửa tên, loại tài khoản, biểu tượng hoặc xoá.
- Có xác nhận trước khi xoá. Lưu ý: giao dịch gắn với tài khoản bị xoá cũng sẽ bị xoá để tránh dữ liệu mồ côi.
- Danh sách ngân hàng/ví hiển thị huy hiệu chữ viết tắt và màu nhận diện khác nhau; đây là huy hiệu nhận diện trong ứng dụng, **chưa phải bộ logo ảnh chính thức của từng thương hiệu**. Có thể gắn ảnh logo riêng cho tài khoản qua trình chọn ảnh.
- Giữ nguyên applicationId `vn.rais.thuchi`; versionCode 11 để cài cập nhật lên bản cũ nếu ký bằng đúng keystore hiện tại.

- Sửa luồng chọn logo khi thêm mới tài khoản: chọn ảnh xong sẽ tạo tài khoản cùng ảnh đó, không cố cập nhật ID -1.
- Sửa luồng đổi logo tài khoản hiện có, lưu quyền đọc URI ảnh lâu dài.
- Khi đổi tên tài khoản, các giao dịch đang gắn với tên cũ được cập nhật cùng trong transaction SQLite để không bị tách lịch sử.
- Xóa tài khoản và giao dịch liên quan trong transaction SQLite, sau đó làm mới widget số dư.
- Logo thương hiệu: do môi trường đóng gói hiện tại không truy cập mạng để tải bộ ảnh chính thức, bản này vẫn dùng huy hiệu chữ viết tắt/màu nhận diện làm mặc định; ảnh logo riêng của người dùng được hỗ trợ lưu cục bộ. Chưa tuyên bố đây là bộ logo chính thức hoàn chỉnh.

## Rais Wallet 0.6.4 — account sources and offline bank logos
- Expanded the searchable bank/e-wallet picker and added `Nguồn khác / chưa xác định` plus `Tạo nguồn tùy chỉnh`.
- Custom sources support a user-defined name, type, and image logo chosen from the device. The image is committed when the user presses Add/Save in the account form, preventing the previous automatic duplicate-add behavior.
- Account cards resolve bundled bank-logo drawable resources when available, with a branded monogram fallback.
- The GitHub Actions workflow downloads supported bank logo PNGs from the logo endpoint documented by MoMo Developers at build time and bundles them into the APK. The installed app can then show these downloaded images offline. If a source endpoint no longer serves a particular code, the build continues and that bank falls back to its monogram.
- `applicationId` remains `vn.rais.thuchi`; use the same release keystore for upgrades.
- The build workflow must run with network access to fetch logos. Logo sources are third-party provider endpoints and may change; verify the final APK artifact after running Actions.


## Bank logo packaging (0.6.4)
The release workflow fetches the official/public bank catalog from VietQR API and packages logo images into `drawable-nodpi` before compiling. The app displays packaged logos offline. The workflow fails if the catalog cannot be fetched or fewer than 10 real logos are downloaded, instead of silently producing an APK that only shows text badges.
