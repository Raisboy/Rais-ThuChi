package vn.rais.thuchi;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import java.util.*;
public class WalletDb extends SQLiteOpenHelper {
 private final Context app;
 public WalletDb(Context c){super(c,"rais_wallet.db",null,1);app=c.getApplicationContext();}
 public void onCreate(SQLiteDatabase d){
  d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT,title TEXT,category TEXT,amount INTEGER,account TEXT,note TEXT,created INTEGER,include_balance INTEGER DEFAULT 1)");
  d.execSQL("CREATE TABLE accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,kind TEXT,icon TEXT)");
  d.execSQL("CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,target INTEGER,saved INTEGER DEFAULT 0)");
  ContentValues v=new ContentValues();v.put("name","Tiền mặt");v.put("kind","cash");v.put("icon","💵");d.insert("accounts",null,v);
  v=new ContentValues();v.put("name","Ngân hàng");v.put("kind","bank");v.put("icon","🏦");d.insert("accounts",null,v);
 }
 public void onUpgrade(SQLiteDatabase d,int o,int n){}
 public long add(String kind,String title,String cat,long amount,String account,String note,boolean include){
  ContentValues v=new ContentValues();v.put("kind",kind);v.put("title",title);v.put("category",cat);v.put("amount",amount);v.put("account",account);v.put("note",note);v.put("created",System.currentTimeMillis());v.put("include_balance",include?1:0);
  long id=getWritableDatabase().insert("tx",null,v);BalanceWidgetProvider.refresh(app);return id;
 }
 private long scalar(String q){Cursor c=getReadableDatabase().rawQuery(q,null);try{return c.moveToFirst()?c.getLong(0):0;}finally{c.close();}}
 public long total(String kind){return scalar("SELECT COALESCE(SUM(amount),0) FROM tx WHERE kind='"+kind+"' AND include_balance=1");}
 public long balance(){return total("IN")-total("OUT");}
 public ArrayList<Tx> list(int limit){
  ArrayList<Tx> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT id,kind,title,category,amount,account,note,created,include_balance FROM tx ORDER BY created DESC LIMIT "+limit,null);
  try{while(c.moveToNext())a.add(new Tx(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5),c.getString(6),c.getLong(7),c.getInt(8)==1));}finally{c.close();}return a;
 }
 public void delete(long id){getWritableDatabase().delete("tx","id=?",new String[]{""+id});BalanceWidgetProvider.refresh(app);}
 public long addAccount(String name,String kind,String icon){ContentValues v=new ContentValues();v.put("name",name);v.put("kind",kind);v.put("icon",icon);return getWritableDatabase().insert("accounts",null,v);}
 public void updateAccount(long id,String oldName,String name,String kind,String icon){SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{ContentValues v=new ContentValues();if(name!=null)v.put("name",name);if(kind!=null)v.put("kind",kind);if(icon!=null)v.put("icon",icon);d.update("accounts",v,"id=?",new String[]{String.valueOf(id)});if(oldName!=null&&name!=null&&!oldName.equals(name)){ContentValues tx=new ContentValues();tx.put("account",name);d.update("tx",tx,"account=?",new String[]{oldName});}d.setTransactionSuccessful();}finally{d.endTransaction();}BalanceWidgetProvider.refresh(app);}
 public void deleteAccount(long id){SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{Cursor c=d.rawQuery("SELECT name FROM accounts WHERE id=?",new String[]{String.valueOf(id)});String name=null;try{if(c.moveToFirst())name=c.getString(0);}finally{c.close();}if(name!=null){d.delete("tx","account=?",new String[]{name});d.delete("accounts","id=?",new String[]{String.valueOf(id)});}d.setTransactionSuccessful();}finally{d.endTransaction();}BalanceWidgetProvider.refresh(app);}
 public ArrayList<String[]> accounts(){ArrayList<String[]> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT id,name,kind,icon FROM accounts ORDER BY id",null);try{while(c.moveToNext())a.add(new String[]{c.getString(0),c.getString(1),c.getString(2),c.getString(3)});}finally{c.close();}return a;}
 public void addGoal(String name,long target){ContentValues v=new ContentValues();v.put("name",name);v.put("target",target);getWritableDatabase().insert("goals",null,v);}
 public ArrayList<String[]> goals(){ArrayList<String[]> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT name,target,saved FROM goals ORDER BY id DESC",null);try{while(c.moveToNext())a.add(new String[]{c.getString(0),c.getString(1),c.getString(2)});}finally{c.close();}return a;}
 public static class Tx{public long id,amount,time;public String kind,title,category,account,note;public boolean include;Tx(long i,String k,String t,String c,long a,String ac,String n,long tm,boolean in){id=i;kind=k;title=t;category=c;amount=a;account=ac;note=n;time=tm;include=in;}}
}
