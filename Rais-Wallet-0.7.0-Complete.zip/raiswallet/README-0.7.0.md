# Rais Wallet 0.7.0

## Logo ngân hàng
- Tài khoản có biểu tượng `brand:<tên>` sẽ được ánh xạ tới tài nguyên logo ngân hàng theo tên/mã phổ biến (VCB, BIDV, CTG/ICB, VBA/VARB, MB, TCB, ACB, VPB, TPB, STB, HDB, OCB, SHB, MSB, VIB, EIB, SEAB, LPB, BAB, VBB, VAB, ABB, PVcomBank, NCB, KLB, NAB).
- Workflow tải ảnh logo từ danh mục VietQR vào `app/src/main/res/drawable-nodpi` trước khi build và dừng nếu thiếu logo ngân hàng trọng yếu. Nguồn danh mục và trường URL logo: https://www.vietqr.io/api-bank
- Logo được nhúng vào APK, vì vậy không cần Internet để hiển thị sau khi build thành công.
- Nếu một logo không được tải, workflow phải báo lỗi; không nên coi huy hiệu chữ viết tắt là logo chính thức.

## Build
1. Đẩy toàn bộ thư mục dự án lên GitHub.
2. Để `Rais-Wallet-0.7.0-Complete.zip` ở thư mục gốc repository để workflow ưu tiên đúng bản này, hoặc đảm bảo chỉ có một ZIP dự án Rais Wallet phiên bản mới nhất.
3. Cấu hình GitHub Actions secrets hiện có cho keystore. Không thay đổi `applicationId` (`vn.rais.thuchi`) và dùng keystore cũ khi ký bản cập nhật.
4. Chạy workflow release và xem log `Download real bank logos from VietQR catalog`.

## Lưu ý kiểm thử
Môi trường đóng gói không có kết nối tới nguồn ảnh và không có Android SDK/Gradle để chạy build thực tế. Cần xác nhận workflow trên GitHub tải logo và build thành công trước khi cài bản cập nhật.
