# Rais Thu Chi — 0.0.2 (Release project)

Ứng dụng Android Java, lưu dữ liệu cục bộ, không cần tài khoản hay máy chủ.

## Tính năng hiện có
- Tổng quan số dư, tổng thu/chi, giao dịch gần đây.
- Thêm giao dịch thu/chi, danh mục và chọn nguồn tiền.
- Tạo nguồn tiền: tiền mặt, ngân hàng, ví điện tử hoặc tên tùy chỉnh.
- Chọn icon mặc định theo ngân hàng/ví hoặc tải ảnh PNG, JPG/JPEG, WebP từ thiết bị.
- Sổ nợ, báo cáo thu/chi dạng biểu đồ đơn giản, xuất bản sao JSON.
- Widget màn hình chính Android hiển thị số dư, tổng thu và tổng chi; nhấn để mở ứng dụng. Widget cũng ẩn số tiền khi bật chế độ riêng tư trong app.
- Chế độ ẩn/hiện số tiền áp dụng trong ứng dụng và widget; không thay đổi dữ liệu hay phép tính.
- Bật/tắt từng danh mục để kiểm soát danh mục xuất hiện khi tạo giao dịch mới. Giao dịch cũ không bị xóa khi tắt danh mục.
- Chạm giữ giao dịch để bật/tắt việc tính giao dịch đó vào số dư thực tế và báo cáo. Giao dịch vẫn được giữ trong lịch sử; trạng thái được ghi trong SQLite.
- Cơ sở dữ liệu SQLite cục bộ. Schema version 4 có migration thêm cột tính tổng và bảng cấu hình danh mục.
- Cùng `applicationId` `vn.rais.thuchi`; `versionCode` là 3 và `versionName` là `0.0.2`.

## Giới hạn quan trọng
- Chưa kết nối ngân hàng/ví điện tử thật và không tự đồng bộ số dư với ngân hàng.
- Đây là bản nâng cấp chức năng; vẫn cần chạy GitHub Actions và kiểm thử APK release trên thiết bị trước khi phát hành rộng rãi.
- Widget cập nhật khi mở app và sau khi thêm giao dịch/tài khoản; Android có thể giới hạn cập nhật nền.

## Build bản phát hành APK + AAB bằng GitHub Actions
Workflow: `.github/workflows/build-rais-release.yml`.

**Bắt buộc tạo một khóa ký lâu dài của riêng bạn. Không làm mất file keystore hoặc mật khẩu**, vì các bản cập nhật phải ký bằng cùng khóa. Không chia sẻ khóa công khai.

Tạo khóa trên máy có JDK:

```bash
keytool -genkeypair -v -keystore rais-release.jks -alias rais -keyalg RSA -keysize 2048 -validity 10000
```

Trên Windows PowerShell, mã hóa keystore thành Base64 và sao chép vào clipboard:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("rais-release.jks")) | Set-Clipboard
```

Trong GitHub repo vào **Settings → Secrets and variables → Actions → New repository secret**, thêm 4 secrets:
- `RAIS_KEYSTORE_BASE64`: chuỗi Base64 ở trên.
- `RAIS_KEYSTORE_PASSWORD`: mật khẩu keystore.
- `RAIS_KEY_ALIAS`: `rais` (hoặc alias bạn đã chọn).
- `RAIS_KEY_PASSWORD`: mật khẩu của key alias.

Sau đó vào **Actions → Build Rais Thu Chi (Release APK + AAB) → Run workflow**. Artifact chứa `app-release.apk` và `app-release.aab`. Chỉ dùng APK release đã ký bằng khóa riêng này để cài/cập nhật. AAB dùng để tải lên Google Play, nhưng còn phải hoàn thành thông tin ứng dụng, chính sách quyền riêng tư và các yêu cầu xét duyệt của Google Play.

## Cập nhật phiên bản
1. Giữ nguyên `applicationId` là `vn.rais.thuchi`.
2. Giữ nguyên keystore và 3 mật khẩu/alias liên quan.
3. Tăng `versionCode` (luôn phải lớn hơn bản trước) và cập nhật `versionName` trong `app/build.gradle`.
4. Không xóa dữ liệu app hoặc thay đổi tên database `rais_local.db` nếu không có migration.

## Build cục bộ
Dùng JDK 17 và Gradle 8.7; Android SDK Platform 35 và Build Tools 35.0.0. Mở dự án trong Android Studio hoặc chạy `gradle assembleDebug` để thử nghiệm.
