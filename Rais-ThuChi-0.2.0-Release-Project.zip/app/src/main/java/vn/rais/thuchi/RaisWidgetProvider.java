package vn.rais.thuchi;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.text.NumberFormat;
import java.util.Locale;

public class RaisWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        refresh(context, manager, ids);
    }
    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction())) {
            int[] ids = intent.getIntArrayExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS);
            if (ids == null || ids.length == 0) ids = AppWidgetManager.getInstance(context).getAppWidgetIds(new ComponentName(context, RaisWidgetProvider.class));
            refresh(context, AppWidgetManager.getInstance(context), ids);
        }
    }
    static void refresh(Context context, AppWidgetManager manager, int[] ids) {
        MainActivity.DB db = new MainActivity.DB(context);
        NumberFormat nf = NumberFormat.getNumberInstance(new Locale("vi", "VN"));
        long income = db.sum("Thu"), expense = db.sum("Chi"), balance = db.balance();
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_rais);
            views.setTextViewText(R.id.widget_balance, nf.format(balance) + " đ");
            views.setTextViewText(R.id.widget_income, nf.format(income) + " đ");
            views.setTextViewText(R.id.widget_expense, nf.format(expense) + " đ");
            Intent open = new Intent(context, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(context, 100 + id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.widget_open, pi);
            views.setOnClickPendingIntent(R.id.widget_refresh, pi);
            manager.updateAppWidget(id, views);
        }
        db.close();
    }
}
