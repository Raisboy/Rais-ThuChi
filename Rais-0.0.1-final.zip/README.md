# Rais thu chi — v0.0.1

Android app Java, SQLite offline. Application ID `vn.rais.thuchi`, versionName `0.0.1`, versionCode `1`.

Features: overview, income/expense transactions, accounts and wallets, debt records, income/expense chart, JSON export.

## Build using GitHub Actions
Upload this project as a ZIP file in the repository root. Then use `.github/workflows/build-android-apk.yml`. Leave `zip_name` empty to select the ZIP with the latest commit affecting it, or enter a specific ZIP filename.

For reliable install-over updates, keep the same applicationId and use the same release keystore for every release. Increase versionCode for each update. Debug APKs are for testing only and may not install over previous builds.
