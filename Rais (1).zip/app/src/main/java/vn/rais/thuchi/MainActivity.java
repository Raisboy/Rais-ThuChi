package vn.rais.thuchi;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private static final int GREEN = Color.rgb(23,107,91), DARK = Color.rgb(19,47,43);
    private static final int BG = Color.rgb(246,249,248), MUTED = Color.rgb(111,128,124);
    private DB db;
    private LinearLayout root, content, bottom;
    private String page = "home";
    private final NumberFormat money = NumberFormat.getNumberInstance(new Locale("vi","VN"));
    private final String[] categories = {"Ăn uống","Di chuyển","Mua sắm","Hóa đơn","Lương","Thưởng","Sức khỏe","Giải trí","Gia đình","Khác"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        getWindow().setStatusBarColor(Color.rgb(16,77,67));
        getWindow().setNavigationBarColor(Color.WHITE);
        showPage("home");
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(1); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private void pad(View v, int a, int b, int c, int d) { v.setPadding(dp(a),dp(b),dp(c),dp(d)); }
    private String fmt(long n) { return money.format(n) + " đ"; }
    private long total(String type) { return db.sum(type); }
    private void showPage(String p) {
        page = p;
        root = column(); root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout header = row(); pad(header,20,16,20,12);
        header.addView(text("Rais",26,GREEN,true), new LinearLayout.LayoutParams(0,dp(40),1));
        TextView avatar = text("R",18,Color.WHITE,true); avatar.setGravity(Gravity.CENTER); avatar.setBackground(bg(GREEN,50));
        header.addView(avatar,lp(40,40)); root.addView(header);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false);
        content = column(); pad(content,18,4,18,20); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if (p.equals("home")) home();
        else if (p.equals("transactions")) transactions();
        else if (p.equals("accounts")) accounts();
        else if (p.equals("debts")) debts();
        else if (p.equals("reports")) reports();
        else if (p.equals("settings")) settings();
        bottomNav();
    }
    private void title(String s, String sub) {
        content.addView(text(s,23,DARK,true));
        if (sub != null) { TextView t=text(sub,13,MUTED,false); LinearLayout.LayoutParams m=lp(-1,-2);m.topMargin=dp(4);content.addView(t,m); }
        space(14);
    }
    private void space(int h) { View v=new View(this); content.addView(v,lp(1,h)); }
    private void card(View v) {
        LinearLayout.LayoutParams m=lp(-1,-2); m.bottomMargin=dp(12);
        v.setBackground(bg(Color.WHITE,20)); v.setElevation(dp(1)); pad(v,16,15,16,15); content.addView(v,m);
    }
    private void label(String s) { TextView t=text(s,14,MUTED,false); LinearLayout.LayoutParams m=lp(-1,-2);m.bottomMargin=dp(7);content.addView(t,m); }
    private void home() {
        title("Tổng quan tài chính","Theo dõi tiền của bạn trong một nơi.");
        LinearLayout balance=column(); balance.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{GREEN,Color.rgb(39,147,119)})); balance.setCornerRadius(dp(24)); pad(balance,20,20,20,20);
        balance.addView(text("TỔNG SỐ DƯ",12,Color.rgb(218,245,235),true));
        TextView val=text(fmt(db.balance()),29,Color.WHITE,true); LinearLayout.LayoutParams vm=lp(-1,-2);vm.topMargin=dp(8);balance.addView(val,vm);
        LinearLayout stats=row(); stats.setGravity(Gravity.TOP); LinearLayout inc=column(),out=column();
        inc.addView(text("↗  Tổng thu",13,Color.rgb(219,250,235),false)); inc.addView(text(fmt(total("Thu")),17,Color.WHITE,true));
        out.addView(text("↘  Tổng chi",13,Color.rgb(255,224,220),false)); out.addView(text(fmt(total("Chi")),17,Color.WHITE,true));
        LinearLayout.LayoutParams sm=new LinearLayout.LayoutParams(0,-2,1);sm.topMargin=dp(22);stats.addView(inc,sm);stats.addView(out,sm);balance.addView(stats);
        LinearLayout.LayoutParams bm=lp(-1,-2);bm.bottomMargin=dp(16);content.addView(balance,bm);
        LinearLayout quick=row(); quick.setGravity(Gravity.CENTER); quick.addView(actionChip("＋  Thêm khoản thu",GREEN,()->addTransaction("Thu")),new LinearLayout.LayoutParams(0,dp(48),1));
        View gap=new View(this);quick.addView(gap,lp(10,1)); quick.addView(actionChip("－  Thêm khoản chi",Color.rgb(199,83,76),()->addTransaction("Chi")),new LinearLayout.LayoutParams(0,dp(48),1)); content.addView(quick); space(20);
        LinearLayout section=row();section.addView(text("Giao dịch gần đây",18,DARK,true),new LinearLayout.LayoutParams(0,-2,1));
        section.addView(link("Xem tất cả",()->showPage("transactions")));content.addView(section);space(10);
        List<Tx> txs=db.transactions(5);
        if(txs.isEmpty()) empty("Chưa có giao dịch","Thêm khoản thu hoặc chi đầu tiên để bắt đầu.");
        else for(Tx tx:txs) txRow(tx);
        space(8);
        LinearLayout shortcuts=row();
        shortcuts.addView(shortcut("🏦","Tài khoản",()->showPage("accounts")),new LinearLayout.LayoutParams(0,dp(92),1));
        shortcuts.addView(shortcut("🤝","Khoản nợ",()->showPage("debts")),new LinearLayout.LayoutParams(0,dp(92),1));
        shortcuts.addView(shortcut("📊","Báo cáo",()->showPage("reports")),new LinearLayout.LayoutParams(0,dp(92),1));
        content.addView(shortcuts);
    }
    private TextView actionChip(String s,int color,Runnable r) {
        TextView t=text(s,13,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(bg(color,14));t.setOnClickListener(v->r.run());return t;
    }
    private TextView link(String s,Runnable r) { TextView t=text(s,13,GREEN,true);t.setOnClickListener(v->r.run());return t; }
    private View shortcut(String icon,String name,Runnable r) {
        LinearLayout l=column();l.setGravity(Gravity.CENTER);l.setBackground(bg(Color.WHITE,17));TextView i=text(icon,23,GREEN,true);i.setGravity(Gravity.CENTER);l.addView(i);TextView n=text(name,12,DARK,true);n.setGravity(Gravity.CENTER);l.addView(n);l.setOnClickListener(v->r.run());return l;
    }
    private void empty(String a,String b) {
        LinearLayout e=column();e.setGravity(Gravity.CENTER);pad(e,16,24,16,24);e.addView(text("◌",30,GREEN,true));
        TextView x=text(a,16,DARK,true);x.setGravity(Gravity.CENTER);e.addView(x);TextView y=text(b,13,MUTED,false);y.setGravity(Gravity.CENTER);e.addView(y);card(e);
    }
    private void txRow(Tx tx) {
        LinearLayout r=row();LinearLayout icon=column();icon.setGravity(Gravity.CENTER);icon.setBackground(bg(tx.type.equals("Thu")?0xFFE2F6EC:0xFFFFE9E5,13));
        TextView ic=text(tx.type.equals("Thu")?"↗":"↘",19,tx.type.equals("Thu")?GREEN:0xFFC6534C,true);ic.setGravity(Gravity.CENTER);icon.addView(ic);r.addView(icon,lp(42,42));
        LinearLayout mid=column();LinearLayout.LayoutParams mm=new LinearLayout.LayoutParams(0,-2,1);mm.leftMargin=dp(12);r.addView(mid,mm);
        mid.addView(text(tx.category,15,DARK,true));mid.addView(text(tx.note.isEmpty()?tx.account:tx.note,12,MUTED,false));
        TextView amount=text((tx.type.equals("Thu")?"+":"−")+fmt(tx.amount),14,tx.type.equals("Thu")?GREEN:0xFFC6534C,true);r.addView(amount);
        LinearLayout.LayoutParams m=lp(-1,-2);m.bottomMargin=dp(14);content.addView(r,m);
    }
    private void transactions() {
        title("Giao dịch","Toàn bộ khoản thu và chi đã ghi nhận.");
        TextView add=actionChip("＋  Thêm giao dịch",GREEN,()->addTransaction(null));content.addView(add,lp(-1,48));space(16);
        List<Tx> list=db.transactions(500);
        if(list.isEmpty()) { empty("Chưa có giao dịch","Nhấn “Thêm giao dịch” để ghi khoản đầu tiên.");return; }
        for(Tx tx:list) {
            LinearLayout wrap=column();wrap.setBackground(bg(Color.WHITE,16));pad(wrap,14,13,14,13);
            // Render each row inside a compact white card.
            LinearLayout r=row();LinearLayout icon=column();icon.setGravity(Gravity.CENTER);icon.setBackground(bg(tx.type.equals("Thu")?0xFFE2F6EC:0xFFFFE9E5,12));
            TextView ic=text(tx.type.equals("Thu")?"↗":"↘",18,tx.type.equals("Thu")?GREEN:0xFFC6534C,true);ic.setGravity(Gravity.CENTER);icon.addView(ic);r.addView(icon,lp(38,38));
            LinearLayout mid=column();LinearLayout.LayoutParams mm=new LinearLayout.LayoutParams(0,-2,1);mm.leftMargin=dp(10);r.addView(mid,mm);mid.addView(text(tx.category,14,DARK,true));mid.addView(text(tx.date+" · "+tx.account,11,MUTED,false));
            r.addView(text((tx.type.equals("Thu")?"+":"−")+fmt(tx.amount),13,tx.type.equals("Thu")?GREEN:0xFFC6534C,true));wrap.addView(r);
            wrap.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle("Xóa giao dịch?").setMessage("Giao dịch sẽ bị xóa khỏi sổ thu chi.").setNegativeButton("Hủy",null).setPositiveButton("Xóa",(d,w)->{db.deleteTx(tx.id);showPage("transactions");}).show();return true;});
            LinearLayout.LayoutParams m=lp(-1,-2);m.bottomMargin=dp(9);content.addView(wrap,m);
        }
    }
    private void accounts() {
        title("Tài khoản & ví","Theo dõi tiền mặt, ngân hàng và ví điện tử.");
        content.addView(actionChip("＋  Thêm tài khoản",GREEN,()->addAccount()),lp(-1,48));space(14);
        List<String[]> list=db.accounts();
        if(list.isEmpty()) empty("Chưa có tài khoản","Bạn có thể thêm tiền mặt, ngân hàng hoặc ví điện tử.");
        for(String[] a:list) {
            LinearLayout c=column();c.addView(text("🏦  "+a[0],16,DARK,true));TextView bal=text(fmt(Long.parseLong(a[1])),22,GREEN,true);LinearLayout.LayoutParams m=lp(-1,-2);m.topMargin=dp(9);c.addView(bal,m);c.addView(text(a[2],12,MUTED,false));card(c);
        }
        label("Lưu ý");content.addView(text("Giao dịch mới có thể gắn với tài khoản để bạn theo dõi nguồn tiền. Số dư tổng quan được tính từ giao dịch thu/chi.",13,MUTED,false));
    }
    private void debts() {
        title("Sổ nợ","Theo dõi khoản bạn nợ và khoản người khác nợ bạn.");
        content.addView(actionChip("＋  Thêm khoản nợ",GREEN,()->addDebt()),lp(-1,48));space(14);
        List<String[]> list=db.debts();
        if(list.isEmpty()) empty("Chưa có khoản nợ","Thêm khoản vay hoặc khoản cần thu hồi.");
        for(String[] d:list) {
            LinearLayout c=column();LinearLayout r=row();r.addView(text(d[0],16,DARK,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(text(d[1].equals("Tôi nợ")?"CẦN TRẢ":"CẦN THU",11,d[1].equals("Tôi nợ")?0xFFC6534C:GREEN,true));c.addView(r);
            c.addView(text(d[1]+" · "+d[2],12,MUTED,false));TextView amount=text(fmt(Long.parseLong(d[3])),21,d[1].equals("Tôi nợ")?0xFFC6534C:GREEN,true);LinearLayout.LayoutParams m=lp(-1,-2);m.topMargin=dp(8);c.addView(amount,m);
            c.addView(text("Hạn: "+(d[4].isEmpty()?"Chưa đặt":d[4])+"  ·  "+d[5],12,MUTED,false));card(c);
        }
    }
    private void reports() {
        title("Báo cáo","Tổng hợp dòng tiền theo dữ liệu hiện có.");
        long income=total("Thu"), expense=total("Chi"), balance=income-expense;
        LinearLayout c=column();c.addView(text("Tổng thu",13,MUTED,false));c.addView(text(fmt(income),22,GREEN,true));spaceInside(c,10);c.addView(text("Tổng chi",13,MUTED,false));c.addView(text(fmt(expense),22,0xFFC6534C,true));spaceInside(c,10);c.addView(text("Chênh lệch thu − chi",13,MUTED,false));c.addView(text(fmt(balance),22,DARK,true));card(c);
        label("Biểu đồ thu / chi");
        LinearLayout chart=column();chart.setBackground(bg(Color.WHITE,20));pad(chart,16,18,16,18);
        chart.addView(new BarChart(this,income,expense),lp(-1,190));card(chart);
        label("Phân loại chi tiêu");
        Map<String,Long> by=db.categoryTotals("Chi"); long max=1;for(long v:by.values())if(v>max)max=v;
        if(by.isEmpty()) empty("Chưa có dữ liệu chi","Biểu đồ phân loại sẽ xuất hiện khi có giao dịch chi.");
        else for(Map.Entry<String,Long> e:by.entrySet()) {
            LinearLayout c2=column();LinearLayout r=row();r.addView(text(e.getKey(),13,DARK,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(text(fmt(e.getValue()),13,DARK,true));c2.addView(r);
            View track=new View(this);track.setBackground(bg(0xFFE8EFEC,8));LinearLayout.LayoutParams tm=lp(-1,7);tm.topMargin=dp(8);c2.addView(track,tm);
            View bar=new View(this);bar.setBackground(bg(GREEN,8));LinearLayout.LayoutParams bm=new LinearLayout.LayoutParams(Math.max(dp(4),(int)(getResources().getDisplayMetrics().widthPixels*.78*e.getValue()/max)),dp(7));bm.topMargin=-dp(7);c2.addView(bar,bm);spaceInside(c2,12);content.addView(c2);
        }
        space(12);content.addView(actionChip("Xuất dữ liệu JSON",GREEN,()->exportJson()),lp(-1,48));
    }
    private void spaceInside(LinearLayout l,int h){View v=new View(this);l.addView(v,lp(1,h));}
    private void settings() {
        title("Cài đặt","Dữ liệu được lưu trực tiếp trên thiết bị.");
        LinearLayout c=column();c.addView(text("🔒  Riêng tư & ngoại tuyến",16,DARK,true));spaceInside(c,8);c.addView(text("Rais không cần đăng nhập và không gửi dữ liệu lên máy chủ. Hãy xuất bản sao JSON định kỳ để tự lưu trữ.",13,MUTED,false));card(c);
        content.addView(actionChip("Xuất bản sao dữ liệu (JSON)",GREEN,()->exportJson()),lp(-1,48));space(12);
        content.addView(actionChip("Xóa toàn bộ dữ liệu",0xFFC6534C,()->new AlertDialog.Builder(this).setTitle("Xóa tất cả dữ liệu?").setMessage("Không thể hoàn tác thao tác này.").setNegativeButton("Hủy",null).setPositiveButton("Xóa",(d,w)->{db.clearAll();showPage("home");}).show()),lp(-1,48));
        space(20);content.addView(text("Rais thu chi · Phiên bản 1.0.0",12,MUTED,false));
    }
    private void bottomNav() {
        bottom=row();bottom.setBackgroundColor(Color.WHITE);bottom.setElevation(dp(10));pad(bottom,4,8,4,8);
        String[][] items={{"home","⌂","Tổng quan"},{"transactions","↕","Giao dịch"},{"accounts","▣","Tài khoản"},{"debts","↔","Sổ nợ"},{"reports","▥","Báo cáo"}};
        for(String[] it:items){LinearLayout item=column();item.setGravity(Gravity.CENTER);TextView i=text(it[1],20,page.equals(it[0])?GREEN:MUTED,true);i.setGravity(Gravity.CENTER);TextView t=text(it[2],10,page.equals(it[0])?GREEN:MUTED,page.equals(it[0]));t.setGravity(Gravity.CENTER);item.addView(i);item.addView(t);item.setOnClickListener(v->showPage(it[0]));bottom.addView(item,new LinearLayout.LayoutParams(0,dp(48),1));}
        root.addView(bottom);
    }
    private void addTransaction(String preset) {
        LinearLayout form=column();pad(form,4,4,4,4);
        RadioGroup rg=new RadioGroup(this);rg.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton income=new RadioButton(this);income.setText("Khoản thu");income.setId(1);RadioButton expense=new RadioButton(this);expense.setText("Khoản chi");expense.setId(2);rg.addView(income);rg.addView(expense);rg.check("Chi".equals(preset)?2:1);form.addView(rg);
        EditText amount=field("Số tiền (VNĐ)",true);form.addView(amount);
        EditText note=field("Nội dung / ghi chú",false);form.addView(note);
        Spinner cat=new Spinner(this);ArrayAdapter<String> ca=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,categories);cat.setAdapter(ca);form.addView(cat);
        List<String[]> accs=db.accounts();ArrayList<String> names=new ArrayList<>();for(String[] a:accs)names.add(a[0]);if(names.isEmpty())names.add("Tiền mặt");
        Spinner account=new Spinner(this);account.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));form.addView(account);
        new AlertDialog.Builder(this).setTitle("Thêm giao dịch").setView(form).setNegativeButton("Hủy",null).setPositiveButton("Lưu",null).create();
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Thêm giao dịch").setView(form).setNegativeButton("Hủy",null).setPositiveButton("Lưu",null).create();
        dialog.setOnShowListener(x->dialog.getButton(-1).setOnClickListener(v->{
            String a=amount.getText().toString().replaceAll("[^0-9]","");
            if(a.isEmpty()||Long.parseLong(a)<=0){amount.setError("Nhập số tiền hợp lệ");return;}
            String type=rg.getCheckedRadioButtonId()==2?"Chi":"Thu";
            String date=new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date());
            db.addTx(type,categories[cat.getSelectedItemPosition()],note.getText().toString().trim(),names.get(account.getSelectedItemPosition()),Long.parseLong(a),date);
            dialog.dismiss();showPage("home");
        }));dialog.show();
    }
    private EditText field(String hint,boolean numeric) {
        EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(15);
        if(numeric)e.setInputType(2);else e.setInputType( android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        LinearLayout.LayoutParams m=lp(-1,52);m.bottomMargin=dp(6);e.setLayoutParams(m);return e;
    }
    private void addAccount() {
        LinearLayout f=column();EditText name=field("Tên tài khoản (VD: Tiền mặt, Vietcombank)",false);EditText balance=field("Số dư ban đầu (VNĐ)",true);EditText kind=field("Loại tài khoản (Ngân hàng / Tiền mặt / Ví)",false);f.addView(name);f.addView(balance);f.addView(kind);
        new AlertDialog.Builder(this).setTitle("Thêm tài khoản").setView(f).setNegativeButton("Hủy",null).setPositiveButton("Lưu",(d,w)->{
            String n=name.getText().toString().trim();if(n.isEmpty())return;long b=0;try{b=Long.parseLong(balance.getText().toString().replaceAll("[^0-9]",""));}catch(Exception ignored){}
            db.addAccount(n,b,kind.getText().toString().trim().isEmpty()?"Tài khoản":kind.getText().toString().trim());showPage("accounts");
        }).show();
    }
    private void addDebt() {
        LinearLayout f=column();EditText person=field("Tên người / nội dung khoản nợ",false);EditText amount=field("Số tiền (VNĐ)",true);EditText due=field("Ngày đến hạn (YYYY-MM-DD, tùy chọn)",false);EditText note=field("Ghi chú",false);
        Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Tôi nợ","Người khác nợ tôi"}));
        f.addView(person);f.addView(amount);f.addView(type);f.addView(due);f.addView(note);
        new AlertDialog.Builder(this).setTitle("Thêm khoản nợ").setView(f).setNegativeButton("Hủy",null).setPositiveButton("Lưu",(d,w)->{
            String a=amount.getText().toString().replaceAll("[^0-9]","");String p=person.getText().toString().trim();if(a.isEmpty()||p.isEmpty())return;
            db.addDebt(p,type.getSelectedItem().toString(),note.getText().toString(),Long.parseLong(a),due.getText().toString().trim());showPage("debts");
        }).show();
    }
    private void exportJson() {
        try {
            JSONObject obj=db.exportData();String name="Rais-backup-"+new SimpleDateFormat("yyyyMMdd-HHmm",Locale.US).format(new Date())+".json";
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,name);
            exportPayload=obj.toString(2);startActivityForResult(i,810);
        } catch(Exception e){Toast.makeText(this,"Không thể tạo bản sao: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private String exportPayload="";
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==810&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(exportPayload.getBytes("UTF-8"));Toast.makeText(this,"Đã xuất bản sao JSON",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Lỗi ghi tệp",Toast.LENGTH_LONG).show();}}}

    private static class BarChart extends View {
        Paint p=new Paint(3);long income,expense;
        BarChart(Context c,long a,long b){super(c);income=a;expense=b;}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();float base=h-35;float max=Math.max(1,Math.max(income,expense));float bw=Math.min(w*.22f,90);float scale=(h-75)/max;float x1=w*.30f-bw/2,x2=w*.70f-bw/2;
            p.setColor(0xFFE8EFEC);c.drawLine(0,base,w,base,p);
            p.setColor(0xFF2AA77F);c.drawRoundRect(x1,base-(float)income*scale,x1+bw,base,12,12,p);
            p.setColor(0xFFE87970);c.drawRoundRect(x2,base-(float)expense*scale,x2+bw,base,12,12,p);
            p.setTextAlign(Paint.Align.CENTER);p.setTextSize(12);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));p.setColor(0xFF334A44);
            c.drawText("Thu",x1+bw/2,h-10,p);c.drawText("Chi",x2+bw/2,h-10,p);
            p.setTextSize(10);c.drawText(shortNum(income),x1+bw/2,Math.max(13,base-(float)income*scale-8),p);c.drawText(shortNum(expense),x2+bw/2,Math.max(13,base-(float)expense*scale-8),p);
        }
        String shortNum(long n){if(n>=1000000000)return String.format(Locale.US,"%.1fB",n/1e9);if(n>=1000000)return String.format(Locale.US,"%.1fM",n/1e6);if(n>=1000)return String.format(Locale.US,"%.0fK",n/1e3);return ""+n;}
    }
    private static class Tx {long id,amount;String type,category,note,account,date;Tx(long i,String t,String c,String n,String a,long v,String d){id=i;type=t;category=c;note=n;account=a;amount=v;date=d;}}
    private static class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"rais_local.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT,category TEXT,note TEXT,account TEXT,amount INTEGER,date TEXT)");
            d.execSQL("CREATE TABLE accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,balance INTEGER,kind TEXT)");
            d.execSQL("CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT,person TEXT,type TEXT,note TEXT,amount INTEGER,due TEXT,status TEXT)");
            d.execSQL("INSERT INTO accounts(name,balance,kind) VALUES('Tiền mặt',0,'Tiền mặt')");
        }
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        void addTx(String t,String c,String n,String a,long v,String date){android.content.ContentValues x=new android.content.ContentValues();x.put("type",t);x.put("category",c);x.put("note",n);x.put("account",a);x.put("amount",v);x.put("date",date);getWritableDatabase().insert("tx",null,x);}
        void deleteTx(long id){getWritableDatabase().delete("tx","id=?",new String[]{""+id});}
        long sum(String type){long v=0;try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE type=?",new String[]{type})){if(c.moveToFirst())v=c.getLong(0);}return v;}
        long balance(){long opening=0;try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(balance),0) FROM accounts",null)){if(c.moveToFirst())opening=c.getLong(0);}return opening+sum("Thu")-sum("Chi");}
        List<Tx> transactions(int limit){ArrayList<Tx> l=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT id,type,category,note,account,amount,date FROM tx ORDER BY id DESC LIMIT "+limit,null)){while(c.moveToNext())l.add(new Tx(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getLong(5),c.getString(6)));}return l;}
        void addAccount(String n,long b,String k){android.content.ContentValues x=new android.content.ContentValues();x.put("name",n);x.put("balance",b);x.put("kind",k);getWritableDatabase().insertWithOnConflict("accounts",null,x,SQLiteDatabase.CONFLICT_REPLACE);}
        List<String[]> accounts(){ArrayList<String[]> l=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT a.name, a.balance + COALESCE((SELECT SUM(CASE WHEN t.type='Thu' THEN t.amount ELSE -t.amount END) FROM tx t WHERE t.account=a.name),0) AS current_balance, a.kind FROM accounts a ORDER BY a.id",null)){while(c.moveToNext())l.add(new String[]{c.getString(0),""+c.getLong(1),c.getString(2)});}return l;}
        void addDebt(String p,String t,String n,long a,String due){android.content.ContentValues x=new android.content.ContentValues();x.put("person",p);x.put("type",t);x.put("note",n);x.put("amount",a);x.put("due",due);x.put("status","Đang mở");getWritableDatabase().insert("debts",null,x);}
        List<String[]> debts(){ArrayList<String[]> l=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT person,type,note,amount,due,status FROM debts ORDER BY id DESC",null)){while(c.moveToNext())l.add(new String[]{c.getString(0),c.getString(1),c.getString(2),""+c.getLong(3),c.getString(4),c.getString(5)});}return l;}
        Map<String,Long> categoryTotals(String type){LinkedHashMap<String,Long> m=new LinkedHashMap<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT category,SUM(amount) FROM tx WHERE type=? GROUP BY category ORDER BY SUM(amount) DESC",new String[]{type})){while(c.moveToNext())m.put(c.getString(0),c.getLong(1));}return m;}
        JSONObject exportData() throws Exception {JSONObject o=new JSONObject();JSONArray t=new JSONArray(),a=new JSONArray(),d=new JSONArray();
            try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM tx",null)){while(c.moveToNext()){JSONObject x=new JSONObject();for(int i=0;i<c.getColumnCount();i++)x.put(c.getColumnName(i),c.getString(i));t.put(x);}}
            try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM accounts",null)){while(c.moveToNext()){JSONObject x=new JSONObject();for(int i=0;i<c.getColumnCount();i++)x.put(c.getColumnName(i),c.getString(i));a.put(x);}}
            try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM debts",null)){while(c.moveToNext()){JSONObject x=new JSONObject();for(int i=0;i<c.getColumnCount();i++)x.put(c.getColumnName(i),c.getString(i));d.put(x);}}
            o.put("app","Rais");o.put("version","1.0.0");o.put("exportedAt",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date()));o.put("transactions",t);o.put("accounts",a);o.put("debts",d);return o;}
        void clearAll(){getWritableDatabase().delete("tx",null,null);getWritableDatabase().delete("debts",null,null);getWritableDatabase().delete("accounts",null,null);getWritableDatabase().execSQL("INSERT INTO accounts(name,balance,kind) VALUES('Tiền mặt',0,'Tiền mặt')");}
    }
}
