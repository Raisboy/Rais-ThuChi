# Rais thu chi — v0.0.1

Ứng dụng Android quản lý thu chi cá nhân, dùng Java + AndroidX + SQLite, chạy ngoại tuyến và không cần tài khoản.

## Phiên bản và cập nhật đè
- `applicationId`: `vn.rais.thuchi` — giữ nguyên ở mọi bản cập nhật.
- `versionName`: `0.0.1`.
- `versionCode`: `1`. Mỗi bản cập nhật tiếp theo phải tăng số này (ví dụ 2, 3, 4...), đồng thời tăng versionName.
- Muốn cài đè mà giữ dữ liệu SQLite, APK mới phải dùng đúng cùng applicationId và được ký bằng đúng cùng keystore. Không gỡ ứng dụng cũ trước khi cập nhật.
- Không đổi cấu trúc/xóa database một cách phá hủy trong các bản cập nhật.

## Tính năng hiện có
- Tổng quan số dư, tổng thu, tổng chi.
- Ghi giao dịch thu/chi, danh mục, ghi chú, tài khoản và ngày ghi nhận.
- Danh sách giao dịch; nhấn giữ một giao dịch để xóa.
- Quản lý tài khoản/ví cơ bản.
- Sổ nợ: khoản cần trả và khoản cần thu.
- Báo cáo thu/chi và biểu đồ cột, tổng chi theo danh mục.
- Xuất dữ liệu JSON bằng hộp thoại lưu tệp Android.
- Lưu dữ liệu cục bộ bằng SQLite.

## GitHub Actions: build APK có thể cập nhật đè
Để APK ở các lần build sau cài đè được lên bản trước, cần tạo và giữ một keystore riêng, không thay đổi nó.

1. Tạo keystore một lần trên máy có Java:
   ```bash
   keytool -genkeypair -v -keystore rais-release.jks -alias rais -keyalg RSA -keysize 2048 -validity 10000
   ```
   Hãy nhớ và giữ an toàn mật khẩu keystore và key. Không tạo lại keystore cho mỗi phiên bản.
2. Mã hóa keystore thành Base64:
   - macOS/Linux: `base64 -w 0 rais-release.jks`
   - Windows PowerShell:
     ```powershell
     [Convert]::ToBase64String([IO.File]::ReadAllBytes("rais-release.jks"))
     ```
3. Trong GitHub repository, mở **Settings → Secrets and variables → Actions → New repository secret**. Tạo các secrets:
   - `RAIS_KEYSTORE_BASE64`: toàn bộ chuỗi Base64
   - `RAIS_KEYSTORE_PASSWORD`: mật khẩu keystore
   - `RAIS_KEY_ALIAS`: `rais`
   - `RAIS_KEY_PASSWORD`: mật khẩu của key
4. Upload `Rais.zip` và `.github/workflows/build-android-apk.yml`, rồi chạy workflow ở tab **Actions**.
5. Khi secrets đã có, tải artifact `Rais-0.0.1-release-apk`. Các bản sau phải dùng lại đúng secrets/keystore này.

Nếu chưa cấu hình signing secrets, workflow chỉ tạo APK debug để thử nghiệm. APK debug đó không nên dùng làm bản phát hành vì khóa debug trên runner có thể thay đổi giữa các lần chạy, khiến bản cập nhật không cài đè được.

## Build local
Mở thư mục dự án trong Android Studio, đồng bộ Gradle, chọn Build > Build APK(s).

## Lưu ý
Min SDK 21, Java 17, compile SDK 35. Hãy xuất JSON định kỳ để có thêm bản sao dữ liệu.
