# Rais Wallet 0.4.0
- Java + AndroidX + Material Components, min SDK 21, compile/target SDK 35.
- App ID preserved: `vn.rais.thuchi`; versionCode 6 / versionName 0.4.0.
- Offline SQLite storage; no login/server; show/hide balance; transactions, reports, accounts, savings goals, JSON export, home-screen widget.
- Upload this ZIP and `.github/workflows/build-rais-release.yml` to the repository. Configure GitHub secrets `RAIS_KEYSTORE_BASE64`, `RAIS_KEYSTORE_PASSWORD`, `RAIS_KEY_ALIAS`, `RAIS_KEY_PASSWORD`.
- Preserve the same release keystore and applicationId for future updates/data continuity.
- Source package only; this environment has not run Android Gradle. Test the GitHub Actions build and install the APK before distributing.
